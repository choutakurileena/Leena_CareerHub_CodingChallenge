package com.careerhub.exception;

public class SalaryCalculationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SalaryCalculationException() {
		// TODO Auto-generated constructor stub
	}

	public SalaryCalculationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
