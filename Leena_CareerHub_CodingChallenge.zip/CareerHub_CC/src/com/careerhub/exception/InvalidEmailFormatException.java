package com.careerhub.exception;

public class InvalidEmailFormatException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidEmailFormatException() {
		// TODO Auto-generated constructor stub
	}

	public InvalidEmailFormatException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
